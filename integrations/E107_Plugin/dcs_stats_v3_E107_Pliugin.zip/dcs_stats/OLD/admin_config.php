<?php
if (!defined('e107_INIT')) { exit; }

class dcs_stats_adminConfig extends e_admin_dispatcher
{
	protected $modes = [
		'main' => [
			'controller' => 'dcs_stats_ui',
			'path' => null,
			'ui' => 'dcs_stats_form_ui',
			'uipath' => null
		]
	];

	protected $adminMenu = [
		'main/config' => [
			'caption' => 'Settings',
			'perm' => 'P'
		]
	];

	protected $menuTitle = 'DCS Stats Settings';
}

class dcs_stats_ui extends e_admin_ui
{
	protected $pluginTitle = 'DCS Stats';
	protected $pluginName  = 'dcs_stats';
	protected $table       = '';
	protected $prefs = [
		'missionstats_path' => ['title'=>'Mission Stats JSON Path', 'type'=>'text', 'data'=>'str', 'help'=>'Relative path to missionstats.json', 'default'=>'data/missionstats.json'],
		'players_path'      => ['title'=>'Players JSON Path', 'type'=>'text', 'data'=>'str', 'help'=>'Relative path to players.json', 'default'=>'data/players.json'],
		'show_tab1'         => ['title'=>'Show Pilot Credits Tab', 'type'=>'boolean', 'data'=>'int', 'help'=>'Toggle Tab 1'],
		'show_tab2'         => ['title'=>'Show Leaderboard Tab', 'type'=>'boolean', 'data'=>'int', 'help'=>'Toggle Tab 2'],
		'show_tab3'         => ['title'=>'Show Pilot Stats Tab', 'type'=>'boolean', 'data'=>'int', 'help'=>'Toggle Tab 3'],
		'leaderboard_limit' => ['title'=>'Top Players to Show', 'type'=>'number', 'data'=>'int', 'default'=>20],
	];

	public function init()
	{
	}
}

class dcs_stats_form_ui extends e_admin_form_ui
{
}

new dcs_stats_adminConfig;
