<?php
require_once("../../class2.php");
require_once(HEADERF);

// Load standard JSON safely
function load_json_safe($path) {
    return (file_exists($path) && filesize($path) > 0)
        ? json_decode(file_get_contents($path), true)
        : [];
}

// Load supporting files
$players = load_json_safe(e_PLUGIN . "dcs_stats/data/players.json");
$credits = load_json_safe(e_PLUGIN . "dcs_stats/data/credits.json");

$ucidToName = [];
foreach ($players as $player) {
    if (!empty($player['ucid']) && !empty($player['name'])) {
        $ucidToName[$player['ucid']] = $player['name'];
    }
}

$ucidToPoints = [];
foreach ($credits as $entry) {
    if (!empty($entry['player_ucid']) && !empty($entry['points']) && $entry['points'] > 10) {
        $ucidToPoints[$entry['player_ucid']] = $entry['points'];
    }
}

// Initialize leaderboard aggregation
$leaderboard = [];
$file = new SplFileObject(e_PLUGIN . "dcs_stats/data/missionstats.json");
while (!$file->eof()) {
    $line = trim($file->fgets());
    if (!$line) continue;

    $row = json_decode($line, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($row)) continue;

    if (empty($row['player_ucid'])) continue;
    $ucid = $row['player_ucid'];
    if (!isset($leaderboard[$ucid])) {
        $leaderboard[$ucid] = ['kills' => 0, 'deaths' => 0, 'sorties' => 0, 'duration' => 0];
    }
    if ($row['event'] === 'S_EVENT_KILL') $leaderboard[$ucid]['kills']++;
    if ($row['event'] === 'S_EVENT_DEAD') $leaderboard[$ucid]['deaths']++;
    if ($row['event'] === 'S_EVENT_TAKEOFF') $leaderboard[$ucid]['sorties']++;
    if (isset($row['duration'])) $leaderboard[$ucid]['duration'] += $row['duration'];
}

// Output
echo '<style>
.tabbtns button { margin-right: 8px; padding: 6px 14px; font-size: 14px; }
.tabcontent { display: none; }
table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }
th, td { padding: 8px; border: 1px solid #ccc; }
th { background: #f5f5f5; }
</style>
<div class="tabbtns">
  <button onclick="showTab(\'credits\')">Pilot Credits</button>
  <button onclick="showTab(\'leaderboard\')">Leaderboard</button>
</div>';

echo '<div id="credits" class="tabcontent"><h2>Pilot Credits</h2>';
if (!empty($ucidToPoints)) {
    echo '<table><tr><th>Name</th><th>Points</th></tr>';
    foreach ($ucidToPoints as $ucid => $points) {
        $name = $ucidToName[$ucid] ?? $ucid;
        echo "<tr><td>{$name}</td><td>{$points}</td></tr>";
    }
    echo '</table>';
} else {
    echo '<p>No credit data found or JSON file missing.</p>';
}
echo '</div>';

echo '<div id="leaderboard" class="tabcontent"><h2>Leaderboard</h2>';
if (!empty($leaderboard)) {
    echo '<table><tr><th>Name</th><th>Kills</th><th>Deaths</th><th>Sorties</th><th>Duration (min)</th></tr>';
    foreach ($leaderboard as $ucid => $data) {
        $name = $ucidToName[$ucid] ?? $ucid;
        $durationMin = round($data['duration'] / 60);
        echo "<tr><td>{$name}</td><td>{$data['kills']}</td><td>{$data['deaths']}</td><td>{$data['sorties']}</td><td>{$durationMin}</td></tr>";
    }
    echo '</table>';
} else {
    echo '<p>No mission statistics found or JSON file missing.</p>';
}
echo '</div>
<script>
function showTab(id) {
  document.querySelectorAll(".tabcontent").forEach(el => el.style.display = "none");
  const tab = document.getElementById(id);
  if (tab) tab.style.display = "block";
}
document.addEventListener("DOMContentLoaded", function() {
  showTab("credits");
});
</script>';

require_once(FOOTERF);
?>
