<?php
if (!defined('e107_INIT')) { exit; }

$eplug_name        = "DCS Stats";
$eplug_version     = "1.0";
$eplug_author      = "Sky Pirates";
$eplug_url         = "https://skypirates.uk";
$eplug_email       = "admin@skypirates.uk";
$eplug_description = "Displays DCS Server Pilot Statistics, Credits, and Leaderboards.";
$eplug_compatible  = "2.0";
$eplug_folder      = "dcs_stats";
$eplug_menu_name   = "DCS Stats";
$eplug_conffile    = "admin_config.php";
$eplug_icon        = "";
$eplug_icon_small  = "";
$eplug_link        = TRUE;
$eplug_done        = "DCS Stats plugin installed successfully.";

$eplug_prefs = array(
    "missionstats_path" => "data/missionstats.json",
    "players_path"      => "data/players.json",
    "show_tab1"         => 1,
    "show_tab2"         => 1,
    "show_tab3"         => 1,
    "leaderboard_limit" => 20
);

$eplug_uninstall = array(
    "delete_prefs" => TRUE,
    "delete_tables" => FALSE
);
