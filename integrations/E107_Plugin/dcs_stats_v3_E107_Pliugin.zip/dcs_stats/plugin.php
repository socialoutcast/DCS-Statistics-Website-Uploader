<?php
// Plugin metadata for e107

$eplug_name = "DCS Stats";
$eplug_version = "1.0";
$eplug_author = "Converted by ChatGPT";
$eplug_url = "https://your-website.com";
$eplug_email = "you@example.com";
$eplug_description = "Displays DCS stats with a tabbed interface.";
$eplug_compatible = "e107 v2.x";
$eplug_readme = "readme.txt";

// Plugin folder
$eplug_folder = "dcs_stats";

// Main plugin file
$eplug_conffile = "admin_config.php";

// Menu file (optional)
$eplug_menu_name = "dcs_stats";

// Icon images (optional)
$eplug_icon = "";
$eplug_icon_small = "";

// Preferences and database tables (not used here)
$eplug_prefs = array();
$eplug_table_names = array();
?>
