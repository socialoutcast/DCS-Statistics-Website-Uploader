<?php
// English language file for DCS Stats Plugin

define("LAN_PLUGIN_DCS_STATS_NAME", "DCS Stats");
define("LAN_PLUGIN_DCS_STATS_DESCRIPTION", "Displays DCS stats with tabbed interface.");
?>
